g++ main.cpp -o load-model -std=c++11 -lGL -lGLU -lglut && ./load-model
